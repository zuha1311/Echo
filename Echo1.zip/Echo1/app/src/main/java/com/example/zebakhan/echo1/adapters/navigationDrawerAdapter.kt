package com.example.zebakhan.echo1.adapters

import android.content.Context
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.RelativeLayout
import android.widget.TextView
import com.example.zebakhan.echo1.R
import com.example.zebakhan.echo1.activities.MainActivity
import com.example.zebakhan.echo1.fragments.AboutUsFragment
import com.example.zebakhan.echo1.fragments.FavouritesFragment
import com.example.zebakhan.echo1.fragments.MainScreenFragment
import com.example.zebakhan.echo1.fragments.SettingFragment

class navigationDrawerAdapter (_contentList: ArrayList<String>, _getImages: IntArray, _context: Context)
    : RecyclerView.Adapter<navigationDrawerAdapter.navViewHolder>() {

            var contentList: ArrayList<String>?=null
            var getImages: IntArray?=null
            var mContext: Context?=null

    init {
        this.contentList = _contentList
        this.getImages = _getImages
        this.mContext= _context
    }
    override fun onCreateViewHolder(p0: ViewGroup, p1: Int): navViewHolder {
          var itemView =   LayoutInflater.from(p0?.context)
                .inflate(R.layout.row_custon_navigationdrwer, p0, false)

        val returnThis = navViewHolder(itemView)
        return returnThis
    }

    override fun getItemCount(): Int {

            return (contentList as ArrayList).size
    }

    override fun onBindViewHolder(p0: navViewHolder, p1: Int) {
        p0?.icon_GET?.setBackgroundResource(getImages?.get(p1) as Int)
        p0?.text_GET?.setText(contentList?.get(p1))
        p0?.content_Holder?.setOnClickListener({
            if (p1==0){
                val mainScreenFragment= MainScreenFragment()
                (mContext as MainActivity).supportFragmentManager
                    .beginTransaction()
                    .replace(R.id.details_fragment, mainScreenFragment)
                    .commit()
            } else if(p1==1)
            {
                val favoriteFragment= FavouritesFragment()
                (mContext as MainActivity).supportFragmentManager
                    .beginTransaction()
                    .replace(R.id.details_fragment, favoriteFragment)
                    .commit()
            } else if (p1==2) {
                val settingsFragment = SettingFragment()
                (mContext as MainActivity).supportFragmentManager
                    .beginTransaction()
                    .replace(R.id.details_fragment, settingsFragment)
                    .commit()
            } else{
                val aboutusFragment = AboutUsFragment()
                (mContext as MainActivity).supportFragmentManager
                    .beginTransaction()
                    .replace(R.id.details_fragment, aboutusFragment)
                    .commit()
            }
            MainActivity.Statified.drawerLayout?.closeDrawers()
        })

    }


    class navViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
            var icon_GET: ImageView?=null
            var text_GET: TextView?=null
            var content_Holder: RelativeLayout?=null

        init {
            icon_GET= itemView?.findViewById(R.id.icon_navdrawer)
            text_GET= itemView?.findViewById(R.id.text_navdrawer)
            content_Holder= itemView?.findViewById(R.id.navdrawer_item_content_holder)
        }
}

}